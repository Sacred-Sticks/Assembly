﻿using System;
using System.Linq;

namespace Assembly
{
    public abstract class Operation
    {
        public abstract void Operate();
    }
}
